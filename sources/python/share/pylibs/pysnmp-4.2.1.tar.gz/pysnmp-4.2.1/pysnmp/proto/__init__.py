"""
    SNMP framework for Python.

    The pysnmp.proto sub-package implements various SNMP protocols.

   Copyright 1999-2004 by Ilya Etingof <ilya@glas.net>. See LICENSE for details.
"""
