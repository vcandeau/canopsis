.. currentmodule:: kombu.messaging
.. _guide-consumers:

===========
 Consumers
===========

.. _consumer-basics:

Basics
======


Reference
=========

.. module:: kombu.messaging

.. autoclass:: Consumer
    :noindex:
    :members:
