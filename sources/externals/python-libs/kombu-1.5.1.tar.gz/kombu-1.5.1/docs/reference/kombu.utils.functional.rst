kombu.utils.functional
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.functional

.. automodule:: kombu.utils.functional
    :members:
    :undoc-members:
