#
# txAMQP Helpers
# 