Pycairo Documentation
=====================

.. module:: cairo

.. toctree::
   :maxdepth: 1

   overview
   reference/index
   faq
   pycairo_c_api


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
