
def raise_error(error, message):
    raise error(message)

