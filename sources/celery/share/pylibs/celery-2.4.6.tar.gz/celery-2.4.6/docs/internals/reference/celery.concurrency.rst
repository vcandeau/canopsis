==================================
 celery.concurrency
==================================

.. contents::
    :local:
.. currentmodule:: celery.concurrency

.. automodule:: celery.concurrency
    :members:
    :undoc-members:
