=================================
 celery - Distributed Task Queue
=================================

.. image:: http://cloud.github.com/downloads/ask/celery/celery_128.png

.. include:: ../includes/introduction.txt

.. include:: ../includes/resources.txt
